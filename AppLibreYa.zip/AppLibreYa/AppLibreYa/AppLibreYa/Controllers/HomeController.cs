
using AppLibreYa.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Microsoft.Data.SqlClient;

namespace AppLibreYa.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration _configuration;

        public HomeController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        // 1. Pantalla principal (Inicio de Sesión)
        public IActionResult Index()
        {
            return View();
        }

        // ACCIÓN: Cuando le dan clic a "INICIAR SESIÓN"
        [HttpPost]
        public IActionResult Login()
        {
            // Simulamos que el usuario es correcto y lo enviamos al mapa principal
            return RedirectToAction("Dashboard");
        }

        // 2. Pantalla de Crear Cuenta
        public IActionResult Registro()
        {
            return View();
        }

        // ACCIÓN: Cuando le dan clic a "REGISTRARME"
        [HttpPost]
        public IActionResult GuardarUsuario()
        {
            // Simulamos que se guardó en la base de datos
            TempData["MensajeExito"] = "Cuenta creada con éxito. Sistema listo.";
            // Lo devolvemos a la pantalla de Inicio de Sesión
            return RedirectToAction("Index");
        }

        // 3. Pantalla de Recuperar Contraseña
        public IActionResult Recuperar()
        {
            return View();
        }

        // ACCIÓN: Cuando le dan clic a "ENVIAR CÓDIGO"
        [HttpPost]
        public IActionResult EnviarLink()
        {
            // Simulamos que enviamos el correo y generamos un código
            TempData["CodigoGenerado"] = "X7-NEON-99";
            // Lo enviamos a la nueva pantalla para colocar el código
            return RedirectToAction("Restablecer");
        }

        // 4. NUEVA PANTALLA: Restablecer Contraseña
        public IActionResult Restablecer()
        {
            return View();
        }

        // ACCIÓN: Cuando le dan clic a "ACTUALIZAR CONTRASEÑA"
        [HttpPost]
        public IActionResult CambiarPassword()
        {
            TempData["MensajeExito"] = "Contraseña restablecida. Acceso autorizado.";
            return RedirectToAction("Index");
        }
        public IActionResult Metricas()
        {
            return View();
        }
        public IActionResult ManualUsuario()
        {
            return View();
        }
        public IActionResult Configuracion()
        {
            return View();
        }
        public IActionResult Dashboard()
        {
            var model = new DashboardViewModel
            {
                Zonas = new List<ZonaParqueo>()
            };

            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // Consulta para traer solo lo necesario para el mapa
                string query = "SELECT Nombre_Zona, Estado FROM Dim_Zonas";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var zona = new ZonaParqueo
                        {
                            Nombre_Zona = reader["Nombre_Zona"].ToString(),
                            Estado = reader["Estado"].ToString(),
                            // Asignamos una clase CSS basada en el nombre para el mapa
                            ClaseCss = "spot-" + reader["Nombre_Zona"].ToString().Replace("-", "")
                        };
                        model.Zonas.Add(zona);
                    }
                }
            }

            // Calculamos los totales en tiempo real
            model.TotalLibres = model.Zonas.Count(z => z.Estado == "Disponible");
            model.TotalOcupados = model.Zonas.Count(z => z.Estado == "Ocupado");

            return View(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}