﻿namespace AppLibreYa.Models
{
    public class DashboardViewModel
    {
        public List<ZonaParqueo> Zonas { get; set; }
        public int TotalLibres { get; set; }
        public int TotalOcupados { get; set; }
    }

    public class ZonaParqueo
    {
        public string Nombre_Zona { get; set; }
        public string Estado { get; set; }
        public string ClaseCss { get; set; } // Lo usaremos para el diseño en el HTML
    }
}