using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppLibreYa.Views.Home
{
    public class RecuperarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
