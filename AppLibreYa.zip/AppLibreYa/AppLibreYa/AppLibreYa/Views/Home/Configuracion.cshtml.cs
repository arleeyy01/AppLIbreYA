using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppLibreYa.Views.Home
{
    public class ConfiguracionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
