using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AppLibreYa.Views.Home
{
    public class RegistroModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
